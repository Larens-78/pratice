---
name: E-Commerce Design System
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#3f4944'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#6f7973'
  outline-variant: '#bec9c2'
  surface-tint: '#1b6b51'
  primary: '#004532'
  on-primary: '#ffffff'
  primary-container: '#065f46'
  on-primary-container: '#8bd6b7'
  inverse-primary: '#8bd6b6'
  secondary: '#545f73'
  on-secondary: '#ffffff'
  secondary-container: '#d5e0f8'
  on-secondary-container: '#586377'
  tertiary: '#393d3f'
  on-tertiary: '#ffffff'
  tertiary-container: '#505456'
  on-tertiary-container: '#c5c8ca'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#a6f2d1'
  primary-fixed-dim: '#8bd6b6'
  on-primary-fixed: '#002116'
  on-primary-fixed-variant: '#00513b'
  secondary-fixed: '#d8e3fb'
  secondary-fixed-dim: '#bcc7de'
  on-secondary-fixed: '#111c2d'
  on-secondary-fixed-variant: '#3c475a'
  tertiary-fixed: '#e0e3e5'
  tertiary-fixed-dim: '#c4c7c9'
  on-tertiary-fixed: '#191c1e'
  on-tertiary-fixed-variant: '#444749'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  container-max-width: 1280px
  gutter-desktop: 24px
  gutter-mobile: 16px
  section-padding-lg: 80px
  section-padding-md: 48px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 32px
---

## Brand & Style

The design system is anchored in a **Corporate/Modern** aesthetic, engineered to establish immediate authority and consumer trust. It prioritizes clarity, precision, and an effortless user journey, ensuring that the interface never distracts from the products being showcased. 

The personality is professional yet accessible—avoiding the coldness of traditional enterprise software through the use of soft grays and intentional whitespace. The target audience values efficiency and reliability; therefore, the UI responds with a structured, predictable layout and high-quality visual cues. This design style leverages subtle depth and high-contrast accents to guide the user's eye toward conversion points without employing aggressive marketing tactics.

## Colors

The color strategy for this design system utilizes a sophisticated **Emerald Green** (`#065F46`) as the primary anchor. This color was selected to evoke a sense of stability, growth, and premium quality. It is used sparingly for primary actions, success states, and brand indicators to maintain its visual impact.

The supporting palette consists of **Deep Navy** (`#1E293B`) for secondary navigation and high-level headings, providing a strong typographic anchor. The background surfaces rely on a tiered system of **Crisp Whites** and **Soft Grays**. This "layering of neutrals" creates a clean canvas that allows product imagery to stand out. Borders and dividers use a subtle gray (`#E2E8F0`) to provide structure without creating visual noise.

## Typography

This design system utilizes **Inter** across all roles to maintain a cohesive, systematic appearance. Inter’s tall x-height and neutral character make it exceptionally legible for product descriptions and price points.

- **Headlines:** Use Semi-Bold (`600`) or Bold (`700`) weights with slight negative letter-spacing to create a dense, authoritative "block" feel for titles.
- **Body Text:** Set primarily in Regular (`400`) weight. The `body-lg` is reserved for product intros, while `body-md` handles the bulk of the descriptive content.
- **Labels:** Medium (`500`) and Semi-Bold (`600`) weights are used for UI elements like buttons, badges, and navigation links to ensure they are easily scannable.

## Layout & Spacing

The design system employs a **Fixed Grid** approach for desktop views, centering content within a 1280px container to maintain readability on wide monitors. On smaller screens, the layout transitions to a **Fluid Grid** with 16px side margins.

A strict **8px spacing scale** governs all spatial relationships. Generous whitespace is a core pillar of the aesthetic; section vertical padding is intentionally large (`80px` for desktop) to prevent the "cluttered shop" feel and allow products to breathe. Internal component spacing should prioritize a "loose" feel—for instance, product cards should utilize `stack-md` (16px) or `stack-lg` (32px) for internal padding to emphasize the premium nature of the brand.

## Elevation & Depth

Hierarchy in this design system is created through a combination of **Ambient Shadows** and **Tonal Layering**. 

1.  **The Base:** The page background is pure white (`#FFFFFF`).
2.  **The Container:** Product cards and sections use a very subtle, light gray background (`#F8FAFC`) or a thin 1px border (`#E2E8F0`) to define their boundaries.
3.  **The Elevation:** We avoid heavy dropshadows. Instead, we use "Subtle Soft Shadows"—a multi-layered shadow with low opacity (e.g., `0px 4px 20px rgba(0, 0, 0, 0.05)`)—to lift product cards and modals off the page. 
4.  **Interaction:** On hover, card elevation should increase slightly, and the shadow should become more diffused to provide tactile feedback without looking "gamey" or overly skeuomorphic.

## Shapes

The shape language is defined as **Rounded (Level 2)**. This specific degree of curvature—0.5rem (8px) for standard components—strikes the perfect balance between professional rigidity and modern friendliness. 

- **Small Components:** Checkboxes and small tags use `rounded-sm` (4px).
- **Standard Components:** Buttons, Input fields, and Card containers use the base `rounded` (8px).
- **Featured Elements:** Hero sections or large promotional banners may use `rounded-lg` (16px) or `rounded-xl` (24px) to create a softer, more inviting focal point.
- **CTAs:** Primary buttons maintain the 8px rounded corner to look substantial and "clickable."

## Components

### Buttons
Primary Call-to-Action buttons use the **Emerald Green** background with white text. They should have a minimum height of 48px to ensure they are touch-friendly. Use a subtle brightness shift (10% darker) for hover states. Secondary buttons use a transparent background with an Emerald or Navy border.

### Product Cards
Cards are the heart of this design system. They must feature a clean white background, a 1px border (`#E2E8F0`), and the "Subtle Soft Shadow" mentioned in the Elevation section. Padding within the card should be a minimum of 24px.

### Input Fields
Inputs use a light gray fill (`#F1F5F9`) and a 1px border. On focus, the border color shifts to the Primary Emerald Green with a soft outer glow. Labels are always placed above the field in `label-md` for maximum clarity.

### Chips & Badges
Use chips for categories and badges for status (e.g., "In Stock"). These should have highly rounded corners (pill-shaped) and use low-saturation background tints of the primary colors to stay secondary to the main CTA.

### Lists & Tables
Data-heavy views like order history should use "Zebra Striping" with the `#F8FAFC` color to maintain line-to-line legibility without the need for heavy vertical borders.